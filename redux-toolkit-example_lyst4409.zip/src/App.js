import logo from "./logo.svg";
import "./App.css";
import Main from "./components/Main";

function App() {
  return (
    <div className="App p-3">
      <Main />
    </div>
  );
}

export default App;
