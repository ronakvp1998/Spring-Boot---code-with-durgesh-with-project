import React, { useState } from "react";
import {
  Button,
  Col,
  Container,
  Form,
  FormControl,
  Row,
} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import DisplayCounter from "./DisplayCounter";
import MinusOne from "./MinusOne";
import PlusOne from "./PlusOne";
import ResetCounter from "./ResetCounter";
import { setValueToCounter } from "../store/slice/CounterSlice";

const Main = () => {
  const counterState = useSelector((state) => state.counter);
  const [value, setValue] = useState(0);
  const dispatch = useDispatch();

  const handleButtonClick = () => {
    //action
    dispatch(setValueToCounter({ value: value }));
  };
  return (
    <Container>
      <h1>Welcome to counter app</h1>
      <DisplayCounter />

      <Row className="mt-2">
        <Col>
          <MinusOne />
        </Col>
        <Col>
          <ResetCounter />
        </Col>
        <Col>
          <PlusOne />
        </Col>
      </Row>

      <div className="mt-4">
        <Form.Group>
          <FormControl
            type="text"
            placeholder="Enter counter value"
            value={value}
            onChange={(event) => setValue(event.target.value)}
          />
        </Form.Group>
        <Container className="mt-3">
          <Button onClick={handleButtonClick}>Set Value</Button>
        </Container>
      </div>
    </Container>
  );
};

export default Main;
