import React from "react";
import { Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { minusOne } from "../store/slice/CounterSlice";
const MinusOne = () => {
  const dispatch = useDispatch();
  return (
    <div>
      <Button
        onClick={(event) => {
          dispatch(minusOne());
        }}
        variant="primary"
      >
        Minus One
      </Button>
    </div>
  );
};

export default MinusOne;
