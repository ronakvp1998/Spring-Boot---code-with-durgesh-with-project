import React from "react";
import { Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { plusOne } from "../store/slice/CounterSlice";

const PlusOne = () => {
  const dispatch = useDispatch();

  const increase = () => {
    //
    dispatch(plusOne());
  };

  return (
    <div>
      <Button onClick={increase} variant="warning">
        Plus One
      </Button>
    </div>
  );
};

export default PlusOne;
