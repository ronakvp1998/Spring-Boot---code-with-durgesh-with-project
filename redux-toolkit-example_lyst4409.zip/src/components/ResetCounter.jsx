import { Button } from "react-bootstrap";
import React from "react";
import { useDispatch } from "react-redux";
import { reset } from "../store/slice/CounterSlice";

const ResetCounter = () => {
  const dispatch = useDispatch();
  return (
    <div>
      <Button
        onClick={(event) => {
          dispatch(reset());
        }}
        variant="dark"
      >
        Rest
      </Button>
    </div>
  );
};

export default ResetCounter;
