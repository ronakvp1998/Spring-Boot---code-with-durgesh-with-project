import { configureStore } from "@reduxjs/toolkit";
import CounterReducer from "./slice/CounterSlice";

const store = configureStore({
  reducer: {
    //reducers goes here
    counter: CounterReducer,
  },
});

export default store;
