import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  countValue: 0,
};

const CounterSlice = createSlice({
  name: "counter",
  initialState: initialState,
  reducers: {
    plusOne: (state, action) => {
      state.countValue += 1;
      return state;
    },
    minusOne: (state, action) => {
      state.countValue -= 1;
      return state;
    },
    reset: (state) => {
      state.countValue = 0;
      return state;
    },
    setValueToCounter: (state, action) => {
      state.countValue = action.payload.value;
      return state;
    },
  },
});

export default CounterSlice.reducer;
export const { plusOne, minusOne, reset, setValueToCounter } =
  CounterSlice.actions;

// create
